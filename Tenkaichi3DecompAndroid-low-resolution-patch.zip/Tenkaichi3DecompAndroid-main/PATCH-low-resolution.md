# Low-resolution scale patch (experimental)

This source patch changes the internal render scale representation from quarters to hundredths and adds 0.25x, 0.30x, and other low scales to both the Android settings screen and the in-game settings menu.

- Android preference key: `scale100`
- Native scale range: 25..800 (0.25x..8.00x)
- Legacy `scale4` settings are read as quarter-scale values and converted.
- `BT3_SCALE` accepts decimal values such as `0.3`.

This is a source patch, not a compiled or tested APK. Build and test on Android before installing. At very low scales, some effects may look different or encounter renderer assumptions.
