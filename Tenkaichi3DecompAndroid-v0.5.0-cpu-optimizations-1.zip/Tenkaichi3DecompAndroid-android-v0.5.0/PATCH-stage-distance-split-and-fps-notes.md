# Stage-only render distance control and FPS behavior

- Split the old combined render-distance setting into `stage_render_distance` (static stage octree/cell culling) and `render_distance` (non-fighter battle objects).
- Added a dedicated `Stage render distance (circular cut)` selector from 10% to 100% in 5% steps. 100% preserves the original stage visibility path; lower values cull stage-tree cells outside a camera-centered horizontal radius, producing approximate circular, blocky cuts.
- Kept a separate `Object render distance` selector. Existing saved `render_distance` values continue to apply to objects; the new stage control defaults to 100%.

## FPS notes

The native port's battle simulation runs at 30 ticks per second by design. `Immediate (uncapped presentation)` removes the display-present VSync wait when supported, but it does not make the simulation tick faster. `Smooth motion` at 60/120/240 renders interpolated in-between pictures while preserving the 30 Hz simulation. Simply removing `Gfx_EndFrame(2)`'s wait would not safely uncap gameplay: movement, hit timing, animation and battle logic assume the original fixed tick. A real simulation-rate change needs a fixed-timestep accumulator and broad gameplay/timing validation; it is intentionally not claimed here.

This source change has not been compiled or profiled on a device in this environment.
