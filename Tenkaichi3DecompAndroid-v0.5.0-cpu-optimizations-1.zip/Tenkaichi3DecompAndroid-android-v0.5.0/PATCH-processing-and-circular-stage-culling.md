# Processing optimization + circular stage render distance

- Changed stage octree distance rejection to use the nearest point of each cell's horizontal XZ footprint against a camera-centered circle. This makes the arena cutoff circular in the ground plane rather than using a 3D bounding-sphere distance.
- Replaced per-cell `sqrtf()` distance calculation with squared-distance comparison. This is a low-risk CPU-side optimization in the hot recursive culling path.
- The octree still culls whole cells, so the circle edge is approximate and may appear as blocky/chunk-like cuts. The camera's current position is the circle center; fighters are not hidden by the battle-object distance control.
- Kept the existing ARM64 renderer optimization flags and all previous resolution, texture, LOD and 1x1 texture options.

## Limits / validation

This is an experimental change. The source archive was inspected and the patch was applied, but a full Android build and device profiling were not performed here. Low values can hide arena geometry and may reveal gaps or affect stage-specific visuals. Test normal battle, split-screen/camera transitions, destructible stages, and all render-distance levels. The CPU benefit is expected to be small-to-moderate and depends on how many octree cells are visited; no FPS gain is guaranteed.
