# Experimental render-distance control

Adds a `Render distance (objects)` option to the Video settings: 100%, 75%, 50%, and 25%. The selected value is persisted as `render_distance`. At 100%, extra culling is disabled. Lower settings hide non-fighter battle objects once their horizontal camera distance exceeds 120 game units multiplied by the selected percentage. Fighter objects are exempt so combatants are not accidentally removed from the view.

Limitations: this is a first experimental step, not a complete render-distance system. It affects non-fighter `BtlObj` instances only; static/baked stage geometry and other renderer draw calls are not culled. Depending on the stage, objects such as destructible props or special models may disappear sooner. Source has not been compiled or tested on a device in this environment; build and test all values, especially split-screen and stage transitions, before relying on it.
