# Experimental texture and model fade controls

This patch adds two controls to the in-game Video settings:

- **Texture resolution**: 100%, 75%, 50%, or 25%. This downsamples game textures after decoding and before GPU upload. It reduces GPU texture memory and upload size, at the cost of blurrier textures. User texture-pack replacements keep their original resolution. Changing the setting affects newly cached texture entries immediately; old entries are evicted by the renderer's normal cache cleanup.
- **Model LOD / fade distance**: 100%, 75%, 50%, or 25%. This scales the existing distance-fade range for models that already use the game's fade flag. It is an experimental approximation, not a complete stage-geometry culling or true mesh-LOD implementation.

The values are persisted in the renderer settings as `texture_scale` and `lod_percent`. The default for both is 100%, preserving the original behavior. These source changes have not been built or tested on a device in this environment; compile and test before distributing or installing.
