# Experimental stage render distance and 1x1 textures

- `Render distance (objects)` now also rejects stage octree cells whose nearest bounding-sphere point is beyond the configured distance. At 100% the original culling path is preserved; lower values may make stage geometry disappear in chunks and can expose hard cuts. This is an approximate stage cull, not a Unity-style streaming/LOD system.
- The texture resolution selector adds `1x1 pixel`. It forces decoded game textures (native game textures, not texture-pack replacements) to a single RGBA pixel before GPU upload. This is deliberately extreme and will make the game look heavily corrupted/flat, but can test texture-memory/performance behavior.
- The stage cutoff uses a 120-game-unit baseline scaled by the same 10..100% setting used for battle objects. It is experimental and needs in-game validation across all stages and split-screen.
- Not built or tested on device in this environment.
