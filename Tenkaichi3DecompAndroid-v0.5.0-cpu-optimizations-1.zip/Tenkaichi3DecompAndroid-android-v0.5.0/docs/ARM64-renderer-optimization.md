# Android ARM64 renderer optimization

This patch changes only the native graphics backend (`port/src/gs/*.c`) and its C++ renderer/UI sources to compile at `-O3` by default. The backend is built for Android `arm64-v8a` / AArch64, where NEON/Advanced SIMD is part of the architecture baseline and Clang can auto-vectorize suitable loops.

The decompiled game logic and the PS2 software-float compatibility path intentionally remain at `-O2`. They use pointer rewriting, a soft-float calling convention, and behavior-sensitive arithmetic; applying `-Ofast`, `-ffast-math`, `-march=native`, or whole-program LTO there would be a higher-risk change and is deliberately avoided.

To build with the previous renderer optimization level for troubleshooting, set:

```sh
BT3_RENDER_OPT=2 python3 port/tools/android.py compile link loader install
```

Default is `BT3_RENDER_OPT=3`. This is a portable ARM64 build, not a device-specific tune for one Snapdragon/Mali chip. `-O3` can improve some CPU-bound render paths but may increase binary size or have no effect on GPU-bound scenes. Measure frame-time/FPS on the target device and compare with `BT3_RENDER_OPT=2`; no performance gain is claimed until benchmarked. No Android APK was compiled or run as part of this source change.
