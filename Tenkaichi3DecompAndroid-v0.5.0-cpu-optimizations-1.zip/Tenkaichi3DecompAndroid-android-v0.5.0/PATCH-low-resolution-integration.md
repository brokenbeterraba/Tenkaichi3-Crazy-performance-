# Integrated low-resolution options (experimental)

Integrated from the supplied low-resolution patch into Android v0.5.0. The Android launcher and in-game native settings now offer 0.25x, 0.30x, 0.50x, 0.75x, 1x and higher scales. The persisted setting is `scale100` (100 = 1x); older `scale4` and `scale` settings are accepted as migration fallbacks. `BT3_SCALE=0.3` is supported.

This source has not been compiled or tested in an Android build here. Very low scales can expose assumptions in effects/render targets.

Render-distance/LOD controls and texture downscaling are not included in this integration yet: those need separate changes to the game's camera/culling and texture upload paths, followed by gameplay testing. Existing texture-pack and screen-filter options are preserved.
